require_relative 'score_improver.rb'

course = Course.new
course.improveScoresMax()
course.print()
